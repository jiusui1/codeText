/**
 * @brief      This class describes a solution.
 * 151. 反转字符串中的单词
 */
class Solution {
public:
    std::string reverseWords(string s) {
        string str = "";
        for (int i = 0; i < s.size(); ++i)
        {
            if
        }
    }
};