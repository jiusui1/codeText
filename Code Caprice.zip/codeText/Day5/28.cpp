

/**
 * @brief      This class describes a solution.
 */
class Solution {
public:
    int strStr(string haystack, string needle) {
        
    }
};